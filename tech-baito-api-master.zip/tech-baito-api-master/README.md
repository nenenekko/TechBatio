## tech-baito-api

postgres はインストールする形で行ってます。

手順とかは Wiki 見てください。
URL: https://gitlab.com/jkk-web/tech-baito-api/-/wikis/setup
