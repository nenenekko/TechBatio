const express = require("express");
let app = express();
const pg = require("pg");
const bodyParser = require("body-parser");
const config = require(__dirname + "/inc/config");

app.use(
  bodyParser.urlencoded({
    extended: true
  })
);
app.use(bodyParser.json());

const initDatabase = function(mainApp) {
  var tables = [];
  const pool = pg.Pool({
    database: config.DB_NAME,
    user: config.DB_USER,
    password: config.DB_PASSWORD,
    host: "localhost",
    port: 5432
  });

  // table の確認
  pool.connect(function(err, client) {
    const query =
      "SELECT table_name FROM information_schema.tables WHERE table_schema='public' AND table_type='BASE TABLE'";
    client.query(query, function(err, result) {
      if (err) {
        console.log(err);
      } else {
        result.rows.forEach(element => {
          tables.push(element.table_name);
        });
        console.log("created tables : ");
        console.log(tables);
      }
    });
  });

  // Skills table add
  // TODO: 初期データ追加
  if (tables.indexOf("skills") === -1) {
    pool.connect(function(err, client) {
      const query = `
      CREATE TABLE skills(
        skill_id SERIAL PRIMARY KEY,
        skill_name varchar(255),
        category_name varchar(255)
      );
      INSERT INTO skills (skill_name, category_name) VALUES 
        ('PostgreSQL', 'バックエンド'),
        ('React.js', 'フロントエンド'),
        ('Nginx', 'バックエンド'),
        ('SASS', 'フロントエンド'),
        ('Swift', 'モバイル'),
        ('Vue.js', 'フロントエンド'),
        ('React Native', 'モバイル'),
        ('Ruby on Rails', 'バックエンド')
      ;
      `;

      client.query(query, function(err, result) {
        if (err.code === '42P07') { // table 重複の error code
          // pass
        } else if (err) {
          console.log(err);
        } else {
          console.log('make table "skills"');
        }
      });
    });
  }

  // user テーブル
  if (tables.indexOf("users") === -1) {
    pool.connect(function(err, client) {
      const query = `
      CREATE TABLE Users(
        user_id varchar(255) NOT NULL,
        name varchar(255),
        mail varchar(255) NOT NULL,
        occupation varchar(255) NOT NULL,
        prefecture varchar(32),
        city varchar(32),
        station varchar(32),
        portfolio varchar(32),
        pr varchar(255)
      );
      `;
      const query2 = `
        INSERT INTO Users VALUES (
          't9JvAlw5xbTXuyFiCfd9AQCI8Q33',
          'ほげほげ 太郎',
          'hogehoge_tarou@gmail.com',
          'student',
          '東京都',
          '調布市',
          '調布駅',
          'http://hogehoge.com',
          'ほげほげです。がんばります。'
        );
      `;
      client.query(query + query2, function(err, result) {
        if (err.code === '42P07') { // table 重複の error code
          // pass
        } else if (err) {
          console.log(err);
        } else {
          console.log('make table "users"');
        }
      });
    });
  }

  // 会社テーブル
  if (tables.indexOf("companies") === -1) {
    pool.connect(function(err, client) {
      const query = `
      CREATE TABLE Companies(
        co_id varchar(32) NOT NULL,
        state varchar(32) NOT NULL,
        co_name varchar(255) NOT NULL,
        department varchar(255),
        representative varchar(255) NOT NULL,
        mail varchar(255) NOT NULL,
        tel varchar(32) NOT NULL,
        fax varchar(32),
        postal varchar(255) NOT NULL,
        prefecture varchar(32) NOT NULL,
        city varchar(32) NOT NULL,
        address varchar(255) NOT NULL,
        url varchar(255)
      );
      `;
      client.query(query, function(err, result) {
        if (err.code === '42P07') { // table 重複の error code
          // pass
        } else if (err) {
          console.log(err);
        } else {
          console.log('make table "companies"');
        }
      });
    });
  }

  // 求人テーブル
  if (tables.indexOf("recruitments") === -1) {
    pool.connect(function(err, client) {
      const query = `
      CREATE TABLE Recruitments(
        recruit_id SERIAL PRIMARY KEY,
        co_id varchar(255) NOT NULL,
        title varchar(255) NOT NULL,
        start_date TIMESTAMP WITH TIME ZONE NOT NULL,
        finish_date TIMESTAMP WITH TIME ZONE NOT NULL,
        explain varchar(255) NOT NULL,
        picture varchar(255),
        postal varchar(255),
        prefecture varchar(255),
        city varchar(255),
        address varchar(255),
        wage integer NOT NULL,
        day_num integer NOT NULL,
        p_language varchar(32),
        skill varchar(32),
        level varchar(32),
        remote varchar(32) NOT NULL,
        tag varchar(32)
      );
      `;
      /**
       * 初期データ: このrequest bodyでひっかかる
       * {"prefecture":"tokyo","city":"sinjuku","minWage":700,"maxWage":1100,"minSift":0,"maxSift":3,"remote":"either"} */

      const query2 = `
      INSERT INTO Recruitments (
        co_id,
        title,
        start_date,
        finish_date,
        explain,
        prefecture,
        city,
        wage,
        day_num,
        remote
      ) VALUES (
        't9JvAlw5xbTXuyFiCfd9AQCI8Q33',
        'init 求人',
        '2020-03-05 09:00:00+09',
        '2020-04-01 09:00:00+09',
        'init 説明',
        'sinjuku',
        'tokyo',
        800,
        2,
        1
      );
      `;
      client.query(query + query2, function(err, result) {
        if (err.code === '42P07') { // table 重複の error code
          // pass
        } else if (err) {
          console.log(err);
        } else {
          console.log('make table "recruitments"');
        }
      });
    });
  }

  if (tables.indexOf("nodejsdata") === -1) {
    pool.connect(function(err, client) {
      const query = `
        CREATE TABLE nodejsdata(
          user_id varchar(32) NOT NULL,
          data1 varchar(255),
          data2 varchar(255),
          data3 varchar(32),
          data4 varchar(32),
          data5 varchar(32));
      `;
      client.query(query, function(err, result) {
        if (err.code === '42P07') { // table 重複の error code
          // pass
        } else if (err) {
          console.log(err);
        } else {
          console.log('make table "nodejsdata"');
        }
      });
    });
  }

  // 応募テーブル
  if (tables.indexOf("applications") === -1) {
    pool.connect(function(err, client) {
      const query = `
      CREATE TABLE applications(
        apply_id SERIAL PRIMARY KEY,
        user_id VARCHAR(255),
        recruit_id INTEGER,
        state INTEGER
      );`;
      // 初期データ入れたいとき
      const query2 = `
        INSERT INTO applications (
          recruit_id, user_id, state
        ) VALUES
        (1, 't9JvAlw5xbTXuyFiCfd9AQCI8Q33', 0),
        (1, 't9JvAlw5xbTXuyFiCfd9AQCI8Q33', 1),
        (1, 't9JvAlw5xbTXuyFiCfd9AQCI8Q33', -1),
        (1, 't9JvAlw5xbTXuyFiCfd9AQCI8Q33', -2),
        (1, 't9JvAlw5xbTXuyFiCfd9AQCI8Q33', 2),
        (1, 't9JvAlw5xbTXuyFiCfd9AQCI8Q33', 0)
        ;
      `;
      client.query(query + query2, function(err, result) {
        if (err.code === '42P07') { // table 重複の error code
          // pass
        } else if (err) {
          console.log(err);
        } else {
          console.log('make table "applications"');
        }
      });
    });
  }
};

exports.initDB = initDatabase;
