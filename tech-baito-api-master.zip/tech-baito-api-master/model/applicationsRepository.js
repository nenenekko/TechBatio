const express = require("express");
const pg = require("pg");
const app = express();
const config = require("../inc/config");

app.get("/api/applications/get_all", function(req, res, next) {
  var pool = pg.Pool({
    database: config.DB_NAME,
    user: config.DB_USER,
    password: config.DB_PASSWORD,
    host: "localhost",
    port: 5432
  });
  pool.connect(function(err, client) {
    if (err) {
      console.log(err);
    } else {
      client.query("SELECT * FROM applications", function(err, result) {
        if (err) {
          console.log(err);
          res.json({ result: false });
        } else {
          res.json({
            data: result.rows,
            result: true
          });
        }
      });
    }
  });
});
app.post("/api/applications/insert", function(req, res, next) {
  var pool = pg.Pool({
    database: config.DB_NAME,
    user: config.DB_USER,
    password: config.DB_PASSWORD,
    host: "localhost",
    port: 5432
  });
  pool.connect(function(err, client) {
    if (err) {
      console.log(err);
    }
    let query = {
      text: `INSERT INTO applications (recruit_id, user_id, state) VALUES ($1, $2, $3) RETURNING apply_id; 
      `,
      values: [req.body.recruit_id, req.body.user_id, req.body.state]
    };
    client.query(query, function(err, result) {
      if (err) {
        console.log(err);
        res.json({
          result: false
        });
      } else {
        res.status(200).json(result.rows[0]);
      }
    });
  });
});

exports.applicationsApp = app;
