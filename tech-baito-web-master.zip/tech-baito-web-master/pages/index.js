import React from "react";
import Layout from "@/components/molecules/Layout";

const Page = () => {
  return (
    <Layout>
      <p>最初のページ</p>
    </Layout>
  );
};

export default Page;
