import React, { useState } from "react";
import Layout from "@/components/molecules/Layout";
import Button from "@/components/atoms/Button";
import Router from "next/router";

const Page = () => {
  // 分野、レベルをstateで管理
  const [category, setCategory] = useState("react");
  const [level, setLevel] = useState(1);

  const handleChange = event => {
    // セレクトボックスの名前を取得
    const name = event.target.name;
    // 選択された値を取得
    const value = event.target.value;
    // stateに値を設定
    if (name === "category") {
      setCategory(value);
      return;
    }
    if (name === "level") {
      setLevel(value);
    }
  };

  const handleClick = () => {
    console.log(`分野: ${category}, レベル: ${level}`);
    // 選択された分野、レベルの値をクエリに入れたページに遷移
    Router.push({
      pathname: "/levelcheck/sample",
      query: {
        category,
        level
      }
    });
  };

  return (
    <Layout>
      <h1>問題・課題に挑戦する</h1>
      <div className="container">
        <div className="select-wrapper">
          分野
          <select name="category" onChange={handleChange} value={category}>
            <option value="react">React</option>
            <option value="vue">Vue</option>
            <option value="angular">Angular</option>
          </select>
        </div>
        <div className="select-wrapper">
          レベル
          <select name="level" onChange={handleChange} value={level}>
            {[...Array(5)].map((_, i) => (
              <option key={i + 1} value={i + 1}>
                {i + 1}
              </option>
            ))}
          </select>
        </div>
        <Button onClick={handleClick}>問題に挑戦する</Button>
      </div>
      <style jsx>{`
        .container {
          display: flex;
          flex-direction: row;
        }
        .select-wrapper {
          display: flex;
          flex-direction: column;
          align-items: center;
          margin-right: 2rem;
        }
      `}</style>
    </Layout>
  );
};
export default Page;
