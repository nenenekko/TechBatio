import React from "react";
import Layout from "@/components/molecules/Layout";
import BoxText from "@/components/atoms/BoxText";
import Button from "../../components/atoms/Button";

const Sample = () => {
  return (
    <Layout>
      <section>
        <div className="title">
          <BoxText>課題</BoxText>
          「ポートフォリオページを作成せよ」
          <div className="button-wrapper">
            <Button color="salmon">提出</Button>
          </div>
        </div>
        ヒント:
        <ul>
          <li>HTML, CSS, JSを使う</li>
          <li>オリジナリティを出そう</li>
        </ul>
      </section>
      <section>
        <div className="title">
          <BoxText>おすすめ教材</BoxText>
        </div>
        <ul>
          <li>本とか</li>
          <li>動画とか</li>
        </ul>
      </section>
      <section>
        <div className="title">
          <BoxText>おすすめツール</BoxText>
        </div>
        <ul>
          <li>Qiitaとか</li>
          <li>Qiitaとか</li>
          <li>Qiitaとか</li>
        </ul>
      </section>
      <style jsx>{`
        section {
          margin-bottom: 2rem;
        }
        .button-wrapper {
          margin-left: auto;
        }
        .title {
          display: flex;
          align-items: center;
          margin-bottom: 1rem;
        }
      `}</style>
    </Layout>
  );
};
export default Sample;
