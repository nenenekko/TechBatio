import React, { useState } from "react";
import Layout from "@/components/molecules/Layout";
import OvalButton from "@/components/atoms/OvalButton";
import Router from "next/router";
import TextInput from "@/components/atoms/TextInput";
import Textarea from "@/components/atoms/Textarea";

const Page = () => {
  // 入力の値を保持するstate
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [occupation, setOccupation] = useState("");
  const [portfolio, setPortfolio] = useState("");
  const [jikopr, setJikopr] = useState("");

  // 編集ボタンをクリックしたときの処理
  const handleClick = () => {
    console.log(name, email, phone, occupation, portfolio, jikopr);
    alert("consoleを見てね");
  };

  // input系が変更されたときの処理
  const handleChange = event => {
    const name = event.target.name;
    const val = event.target.value;

    switch (name) {
      case "name":
        setName(val);
        break;
      case "email":
        setEmail(val);
        break;
      case "phone":
        setPhone(val);
        break;
      case "occupation":
        setOccupation(val);
        break;
      case "portfolio":
        setPortfolio(val);
        break;
      case "jikopr":
        setJikopr(val);
        break;
    }
  };

  return (
    <Layout>
      <h1>マイページ</h1>
      <dl>
        <dt>名前</dt>
        <dd>
          <TextInput
            name="name"
            onChange={handleChange}
            placeholder="ほげ田 ほげ夫"
          />
        </dd>
        <dt>メールアドレス</dt>
        <dd>
          <TextInput
            name="email"
            onChange={handleChange}
            placeholder="hoge@mail.com"
          />
        </dd>
        <dt>電話</dt>
        <dd>
          <TextInput
            name="phone"
            onChange={handleChange}
            placeholder="080-1111-2222"
          />
        </dd>
        <dt>職業</dt>
        <dd>
          <select name="occupation" onChange={handleChange}>
            <option value="student">学生</option>
            <option value="employed">社会人</option>
          </select>
        </dd>
        <dt>ポートフォリオページ</dt>
        <dd>
          <TextInput
            name="portfolio"
            onChange={handleChange}
            placeholder="http://hogeportfolio.com"
          />
        </dd>
        <dt>自己PR</dt>
        <dd>
          <Textarea
            name="jikopr"
            onChange={handleChange}
            placeholder="自分のいいところを書いてね"
          />
        </dd>
        <dt>到達レベル</dt>
        <dd>TODO</dd>
      </dl>
      <div className="button-wrapper">
        <OvalButton onClick={handleClick}>確認</OvalButton>
      </div>

      <style jsx>{`
        /* スタイルはここに書いてね */
        dl {
          display: flex;
          flex-flow: row wrap;
        }
        dt {
          flex-basis: 20%;
          margin-bottom: 2rem;
        }
        dd {
          flex-basis: 70%;
          margin-bottom: 2rem;
        }
        .button-wrapper {
          display: flex;
          justify-content: center;
        }
        .container {
          background: pink;
        }
      `}</style>
    </Layout>
  );
};
export default Page;
