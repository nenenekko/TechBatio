import React from "react";
import Layout from "@/components/molecules/Layout";
import OvalButton from "@/components/atoms/OvalButton";
import Router from "next/router";

const Page = () => {
  // 編集ボタンをクリックしたときの処理
  const handleClick = () => {
    Router.push("/mypage/edit");
  };

  return (
    <Layout>
      <h1>マイページ</h1>
      <dl>
        <dt>名前</dt>
        <dd>ほげた ほげお</dd>
        <dt>メールアドレス</dt>
        <dd>hoge@hoge.com</dd>
        <dt>電話</dt>
        <dd>080-1111-2222</dd>
        <dt>身分</dt>
        <dd>大学生</dd>
        <dt>ポートフォリオページ</dt>
        <dd>http://hogehoge.com</dd>
        <dt>自己PR</dt>
        <dd>
          Webプログラマーとして5年間勤務し、Javaを中心に、C、JavaScriptなどのプログラミング言語を習得いたしました。また、業務ではGithubとQiitaを活用しています。今後は業務の幅を広げたいと考え、〇月のRudy技術者認定試験での資格取得に向けて勉強しております。そうしてプログラマーとしてスキルアップを図り、将来的にはプロジェクトマネージャとしてマネジメントを行いたいと考えています。
        </dd>
        <dt>到達レベル</dt>
        <dd>TODO</dd>
      </dl>
      <div className="button-wrapper">
        <OvalButton onClick={handleClick}>編集</OvalButton>
      </div>

      <style jsx>{`
        /* スタイルはここに書いてね */
        dl {
          display: flex;
          flex-flow: row wrap;
        }
        dt {
          flex-basis: 20%;
          margin-bottom: 1rem;
        }
        dd {
          flex-basis: 70%;
          margin-bottom: 2rem;
        }
        .button-wrapper {
          display: flex;
          justify-content: center;
        }
        .container {
          background: pink;
        }
      `}</style>
    </Layout>
  );
};
export default Page;
