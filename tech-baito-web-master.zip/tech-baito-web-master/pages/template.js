import React from "react";
import Layout from "@/components/molecules/Layout";
const Page = () => {
  return (
    <Layout>
      <div className="container">テンプレートだよ</div>
      <style jsx>{`
        /* スタイルはここに書いてね */
        .container {
          background: pink;
        }
      `}</style>
    </Layout>
  );
};
export default Page;
